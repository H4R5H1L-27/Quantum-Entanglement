
import streamlit as st

st.set_page_config(page_title="Quantum Playground", page_icon="🧪", layout="wide")

st.markdown("<h1 style='text-align:center;'>🧪 Quantum Playground</h1>", unsafe_allow_html=True)
st.write("")
st.markdown(
    '''
    Welcome to the **Quantum Playground** — an interactive web lab for exploring key quantum concepts visually and intuitively.
    Choose a module below to begin your journey into quantum weirdness 👇
    '''
)

st.markdown("---")

col1, col2 = st.columns(2)
with col1:
    st.markdown("### 🌀 Entanglement & Correlation (Bell Test)")
    st.caption("Visualize how entangled particles remain correlated even across distance.")
    st.link_button("Open module", "1_Entanglement_&_Correlation_(Bell_Test)")

    st.markdown("### 🌈 CHSH Inequality: Quantum vs Classical")
    st.caption("Compare classical and quantum correlations, and witness Bell inequality violations.")
    st.link_button("Open module", "2_CHSH_Inequality")

with col2:
    st.markdown("### ✨ Quantum Teleportation Protocol")
    st.caption("Step-by-step visualization of how an unknown quantum state is transmitted via entanglement.")
    st.link_button("Open module", "3_Quantum_Teleportation")

    st.markdown("### ☁️ Decoherence & Noise Models")
    st.caption("Watch pure quantum states decay into classical mixtures under phase/amplitude damping.")
    st.link_button("Open module", "4_Decoherence_&_Noise")

st.markdown("---")
st.markdown("<p style='text-align:center; font-size:13px;'>Quantum Playground © 2025 · Built with ❤️ using Streamlit, NumPy, and Plotly</p>", unsafe_allow_html=True)
