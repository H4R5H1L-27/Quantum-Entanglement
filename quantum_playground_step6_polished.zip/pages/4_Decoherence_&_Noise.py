
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from utils.quantum_ops import single_qubit_state_from_bloch, evolve_under_noise, apply_noise_channel, bloch_vector

st.set_page_config(page_title="Decoherence & Noise", page_icon="☁️", layout="wide")
st.title("☁️ Decoherence & Noise Models")

st.markdown(
    """
    Watch a quantum state **lose coherence** under different noise environments.
    Compare **phase damping** (destroys phase) and **amplitude damping** (relaxes |1⟩→|0⟩).
    """
)

with st.expander("📘 Kraus operators"):
    st.markdown(
        r"""
        **Phase damping:**

        \(E_0=\begin{bmatrix}1&0\\0&\sqrt{1-\gamma}\end{bmatrix},\quad
        E_1=\begin{bmatrix}0&0\\0&\sqrt{\gamma}\end{bmatrix}\)


        **Amplitude damping:**

        \(E_0=\begin{bmatrix}1&0\\0&\sqrt{1-\gamma}\end{bmatrix},\quad
        E_1=\begin{bmatrix}0&\sqrt{\gamma}\\0&0\end{bmatrix}\)


        Evolution: \(\rho' = \sum_i E_i\,\rho\,E_i^\dagger\).
        """
    )

def bloch_figure(vec, title):
    x,y,z = vec
    # sphere wireframe
    u = np.linspace(0, 2*np.pi, 30)
    v = np.linspace(0, np.pi, 15)
    xs = np.outer(np.cos(u), np.sin(v))
    ys = np.outer(np.sin(u), np.sin(v))
    zs = np.outer(np.ones_like(u), np.cos(v))
    fig = go.Figure()
    fig.add_surface(x=xs, y=ys, z=zs, showscale=False, opacity=0.15)
    # axes
    fig.add_scatter3d(x=[-1,1], y=[0,0], z=[0,0], mode="lines", name="X")
    fig.add_scatter3d(x=[0,0], y=[-1,1], z=[0,0], mode="lines", name="Y")
    fig.add_scatter3d(x=[0,0], y=[0,0], z=[-1,1], mode="lines", name="Z")
    # vector
    fig.add_scatter3d(x=[0,x], y=[0,y], z=[0,z], mode="lines+markers", name="state")
    fig.update_layout(title=title, scene=dict(xaxis=dict(range=[-1,1]), yaxis=dict(range=[-1,1]), zaxis=dict(range=[-1,1])))
    return fig

colL, colR = st.columns([1, 1.4])
with colL:
    st.subheader("🎚️ Controls")
    model = st.radio("Noise model", ["phase", "amplitude"], index=0, help="Phase destroys superposition phase; amplitude relaxes |1> to |0>.")
    deg_theta = st.slider("Initial θ (deg)", 0, 180, 60)
    deg_phi = st.slider("Initial φ (deg)", 0, 360, 90)
    steps = st.slider("Resolution (γ steps)", 5, 200, 40, step=5)
    animate = st.checkbox("Animate decoherence (0 → 1)")

    theta = np.deg2rad(deg_theta)
    phi = np.deg2rad(deg_phi)

    gammas = np.linspace(0, 1, steps)
    states, coherences, bloch = evolve_under_noise(theta, phi, gammas, model)
    rho0 = states[0]
    rho1 = states[-1]

    # show initial & final Bloch vectors
    v0 = bloch[0]
    v1 = bloch[-1]

    if animate:
        # Build Plotly frames for smooth animation
        frames = []
        for i, vec in enumerate(bloch):
            x,y,z = vec
            frames.append(go.Frame(data=[
                go.Scatter3d(x=[0,x], y=[0,y], z=[0,z], mode="lines+markers", name="state")
            ], name=f"g={gammas[i]:.2f}"))
        # base figure
        figA = bloch_figure(v0, f"Bloch vector under {model} damping")
        figA.frames = frames
        figA.update_layout(updatemenus=[dict(type="buttons",
                                             buttons=[dict(label="Play", method="animate", args=[None, {"frame": {"duration": 100, "redraw": True}, "fromcurrent": True}]),
                                                      dict(label="Pause", method="animate", args=[[None], {"mode": "immediate", "frame": {"duration": 0, "redraw": False}}])])],
                           sliders=[dict(steps=[dict(method="animate", args=[[f"g={gammas[i]:.2f}"], {"mode":"immediate","frame":{"duration":0,"redraw":True}}], label=f"{gammas[i]:.2f}") for i in range(len(gammas))])])
    else:
        figA = bloch_figure(v1, f"Final Bloch vector at γ=1.0 ({model})")

with colR:
    st.subheader("📉 Coherence and populations vs γ")
    gdeg = gammas * 100
    # Coherence |rho01|
    fig1 = go.Figure()
    fig1.add_scatter(x=gdeg, y=coherences, mode="lines+markers", name="|ρ01|")
    fig1.update_layout(title="Coherence magnitude |ρ01| vs γ", xaxis_title="γ (%)", yaxis_title="|ρ01|")

    # Populations ρ00 and ρ11
    p00 = [np.real(r[0,0]) for r in states]
    p11 = [np.real(r[1,1]) for r in states]
    fig2 = go.Figure()
    fig2.add_scatter(x=gdeg, y=p00, mode="lines+markers", name="ρ00")
    fig2.add_scatter(x=gdeg, y=p11, mode="lines+markers", name="ρ11")
    fig2.update_layout(title="Populations vs γ", xaxis_title="γ (%)", yaxis_title="Probability", yaxis=dict(range=[0,1]))

    # Show plots
    left, right = st.columns(2)
    with left:
        st.plotly_chart(fig1, use_container_width=True)
    with right:
        st.plotly_chart(fig2, use_container_width=True)

st.subheader("🌐 Bloch visualization")
st.plotly_chart(figA, use_container_width=True)

st.markdown("""---""")
with st.expander("🧠 Interpretation"):
    if model == "phase":
        st.markdown(
            """
            **Phase damping:** off-diagonal elements decay to 0 while populations stay constant.
            The Bloch arrow **contracts toward the Z-axis** (losing X/Y components).
            """
        )
    else:
        st.markdown(
            """
            **Amplitude damping:** population leaks from |1⟩ to |0⟩, so ρ₁₁ decreases and ρ₀₀ increases.
            The Bloch arrow **moves toward +Z** (ground state) and also loses transverse components.
            """
        )

st.success("Step 5 complete: Decoherence simulator with animation, coherence decay, and population plots!")
