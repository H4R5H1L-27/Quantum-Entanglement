
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from utils.quantum_ops import (
    single_qubit_state_from_bloch, teleportation_once, teleportation_batch, bloch_vector
)

st.set_page_config(page_title="Quantum Teleportation", page_icon="✨", layout="wide")
st.title("✨ Quantum Teleportation Protocol")

st.markdown(
    """
    Transfer an **unknown quantum state** from **Alice** to **Bob** using a shared entangled pair + **two classical bits**.
    We'll treat **Charlie** as the referee who gives Alice the unknown state and checks that Bob gets it back.
    """
)

with st.expander("🧩 Roles & steps (visual analogy)"):
    st.markdown(
        """
        - **Charlie** prepares a secret arrow on a sphere (the qubit) and hands it to **Alice**.

        - **Alice** and **Bob** share a pair of entangled particles.

        - Alice performs **CNOT** and **H**, then measures her two qubits → two classical bits **m0 m1**.

        - Alice **sends (m0,m1)** to Bob over a classical channel (text message!).

        - **Bob** applies **Z if m0=1** and **X if m1=1** to his qubit.

        - Bob’s qubit **becomes Charlie’s original** — without the state ever traveling!
        """
    )

# Controls
colL, colR = st.columns([1, 1.4])
with colL:
    st.subheader("🎚️ Choose the unknown state |ψ⟩")
    deg_theta = st.slider("θ (polar, degrees)", 0, 180, 60)
    deg_phi = st.slider("φ (azimuthal, degrees)", 0, 360, 90)
    shots = st.slider("Batch shots", 10, 10000, 1000, step=10)
    seed = st.number_input("Random seed (-1 = random)", value=123, step=1)
    run_one = st.button("Run ONE teleportation (show steps)")
    run_many = st.button("Run MANY teleportations (statistics)")

    theta = np.deg2rad(deg_theta)
    phi = np.deg2rad(deg_phi)
    rng = np.random.default_rng(None if seed==-1 else int(seed))

    psi = single_qubit_state_from_bloch(theta, phi)

def bloch_figure(vec, title):
    x,y,z = vec
    # Create a unit sphere wireframe and a vector
    u = np.linspace(0, 2*np.pi, 30)
    v = np.linspace(0, np.pi, 15)
    xs = np.outer(np.cos(u), np.sin(v))
    ys = np.outer(np.sin(u), np.sin(v))
    zs = np.outer(np.ones_like(u), np.cos(v))
    fig = go.Figure()
    # sphere surface (light wireframe look using low opacity)
    fig.add_surface(x=xs, y=ys, z=zs, showscale=False, opacity=0.15)
    # equator & axes
    fig.add_scatter3d(x=[-1,1], y=[0,0], z=[0,0], mode="lines", name="X-axis")
    fig.add_scatter3d(x=[0,0], y=[-1,1], z=[0,0], mode="lines", name="Y-axis")
    fig.add_scatter3d(x=[0,0], y=[0,0], z=[-1,1], mode="lines", name="Z-axis")
    # state vector
    fig.add_scatter3d(x=[0,x], y=[0,y], z=[0,z], mode="lines+markers", name="state")
    fig.update_layout(title=title, scene=dict(xaxis=dict(range=[-1,1]), yaxis=dict(range=[-1,1]), zaxis=dict(range=[-1,1])))
    return fig

with colR:
    st.subheader("🎯 Target vs. Bob's final state (Bloch vectors)")

    if run_one:
        m0, m1, fid, rho_bob, steps = teleportation_once(theta, phi, rng)
        st.markdown(f"**Measurement bits:** m0={m0}, m1={m1}  |  **Fidelity with target:** **{fid:.4f}**")
        st.caption("(Ideal teleportation yields fidelity 1.0 up to numerical precision.)")

        # Bloch vectors
        rho_target = np.outer(psi, np.conjugate(psi))
        v_target = bloch_vector(rho_target)
        v_bob = bloch_vector(rho_bob)

        left, right = st.columns(2)
        with left:
            st.plotly_chart(bloch_figure(v_target, "Target state (Charlie’s |ψ⟩)"), use_container_width=True)
        with right:
            st.plotly_chart(bloch_figure(v_bob, "Bob’s state after corrections"), use_container_width=True)

        with st.expander("🔎 Step probabilities & classical channel"):
            st.write("Outcome probabilities for (m0,m1):", steps['probs_m0m1'])

    if run_many:
        counts, avg_fid = teleportation_batch(theta, phi, shots, rng)
        st.markdown(f"**Average fidelity over {shots} runs:** **{avg_fid:.4f}**")
        labels = ["00","01","10","11"]
        values = [counts[(0,0)], counts[(0,1)], counts[(1,0)], counts[(1,1)]]
        fig = go.Figure()
        fig.add_bar(x=labels, y=values, name="Counts of (m0 m1)")
        fig.update_layout(title="Distribution of classical bits from Alice's measurements", xaxis_title="(m0 m1)", yaxis_title="Counts")
        st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
with st.expander("🧠 What’s happening mathematically?"):
    st.markdown(
        r"""
        - Start with |ψ⟩ ⊗ |Φ⁺⟩, where |Φ⁺⟩ = (|00⟩ + |11⟩)/√2 between Alice (q1) and Bob (q2).
        - Alice applies **CNOT(q0→q1)** and **H(q0)**, then measures q0,q1 → bits (m0,m1).
        - Bob applies **Z^m0 X^m1** to his qubit. The reduced state on Bob becomes **exactly |ψ⟩⟨ψ|**.
        - No superluminal signaling occurs — **two classical bits** are required.
        """
    )

st.success("Step 4 complete: Teleportation with step-by-step visuals and batch statistics!")
