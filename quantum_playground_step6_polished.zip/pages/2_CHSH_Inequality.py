
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from utils.quantum_ops import empirical_correlation, theoretical_correlation, chsh_value, sample_outcomes

st.set_page_config(page_title="CHSH Inequality", page_icon="🌈", layout="wide")
st.title("🌈 CHSH Inequality: Quantum vs Classical Correlations")

st.markdown(
    """
    The **CHSH inequality** tests whether the world can be explained by **local hidden variables**.
    It involves four measurement settings — two for Alice (a, a′) and two for Bob (b, b′):
    \[ S = E(a,b) + E(a,b') + E(a',b) - E(a',b') \]
    **Classical limit:** |S| ≤ 2  ·  **Quantum prediction:** |S| ≤ 2√2 ≈ 2.828
    """)


with st.expander("🎯 Analogy: Correlated lights"):
    st.markdown(
        """
        Imagine two smart lights, A and B. Each has two possible **switch modes** (angles).
        When they share an **entangled program**, their brightnesses are correlated so strongly
        that the joint behavior can't be explained by any hidden local setting — this is Bell’s theorem!
        """)


col1, col2 = st.columns([1, 1.2])
with col1:
    st.subheader("🎚️ Measurement settings")
    deg_a = st.slider("Alice angle a (°)", 0, 180, 0)
    deg_ap = st.slider("Alice angle a′ (°)", 0, 180, 45)
    deg_b = st.slider("Bob angle b (°)", 0, 180, 22)
    deg_bp = st.slider("Bob angle b′ (°)", 0, 180, 67)
    trials = st.slider("Trials per pair", 100, 200000, 5000, step=100)
    seed = st.number_input("Random seed (-1 = random)", value=42, step=1)
    run = st.button("Run CHSH simulation")

    theta_a, theta_ap = np.deg2rad(deg_a), np.deg2rad(deg_ap)
    theta_b, theta_bp = np.deg2rad(deg_b), np.deg2rad(deg_bp)
    rng = np.random.default_rng(None if seed == -1 else int(seed))

    if run:
        S_emp, S_th = chsh_value(theta_a, theta_ap, theta_b, theta_bp, trials=trials, rng=rng)
        st.markdown(f"### Results: |S| (Quantum Empirical) = **{abs(S_emp):.3f}**, Theory = **{abs(S_th):.3f}**")
        st.info("Classical bound: |S| ≤ 2 → Quantum violation occurs if |S| > 2")

        bars = go.Figure()
        bars.add_hline(y=2, line_dash="dot", annotation_text="Classical limit (2)")
        bars.add_hline(y=2*np.sqrt(2), line_dash="dot", annotation_text="Quantum max (2√2)")
        bars.add_bar(x=["Empirical |S|", "Theoretical |S|"], y=[abs(S_emp), abs(S_th)], name="S values")
        bars.update_layout(title="CHSH S-value comparison", yaxis_title="|S|", yaxis=dict(range=[0,3]))
        st.plotly_chart(bars, use_container_width=True)


with col2:
    st.subheader("📈 Sweep over one of Bob’s settings")
    st.markdown("We fix a,a′ and b, and sweep b′ to visualize how S changes.")
    sweep_points = st.slider("Sweep points", 10, 180, 90, step=5)
    sweep_trials = st.slider("Trials per sweep point", 500, 10000, 2000, step=500)
    sweep_range = np.linspace(0, np.pi, sweep_points)
    S_emp_list, S_th_list = [], []
    for bp in sweep_range:
        emp, th = chsh_value(theta_a, theta_ap, theta_b, bp, trials_each=sweep_trials, rng=rng)
        S_emp_list.append(emp)
        S_th_list.append(th)

    fig = go.Figure()
    fig.add_scatter(x=np.rad2deg(sweep_range), y=np.abs(S_emp_list), mode="markers", name="Empirical |S|")
    fig.add_scatter(x=np.rad2deg(sweep_range), y=np.abs(S_th_list), mode="lines", name="Theory |S|")
    fig.add_hline(y=2, line_dash="dot", annotation_text="Classical bound")
    fig.add_hline(y=2*np.sqrt(2), line_dash="dot", annotation_text="Quantum limit 2√2")
    fig.update_layout(title="S-value vs. Bob’s second angle b′", xaxis_title="b′ (degrees)", yaxis_title="|S|", yaxis=dict(range=[0,3]))
    st.plotly_chart(fig, use_container_width=True)


st.markdown("---")
with st.expander("🧠 Behind the scenes"):
    st.markdown(
        r"""
        - The CHSH expression combines four correlation terms E(a,b), E(a,b′), E(a′,b), E(a′,b′).
        - For a **local hidden-variable theory**, |S| ≤ 2.
        - For the **quantum Bell state** |Φ⁺⟩, the correlations follow E = cos(θ_A - θ_B),
          which allows |S| up to 2√2 ≈ 2.828.
        - Violation of the classical limit proves that **no local hidden-variable theory**
          can explain the outcomes — quantum entanglement is genuinely nonlocal.
        """)
st.success("Step 3 complete: CHSH violation visualized and compared to classical limits!")


# --- Optional: Export CHSH sweep data ---
import pandas as pd, io
if run:
    with st.expander("📄 Export Data"):
        data = {"a":[deg_a],"a'":[deg_ap],"b":[deg_b],"b'":[deg_bp],"S_emp":[S_emp],"S_th":[S_th]}
        csv_buf = io.StringIO()
        pd.DataFrame(data).to_csv(csv_buf, index=False)
        st.download_button("Download S-values (CSV)", csv_buf.getvalue(), "chsh_results.csv", "text/csv")
