
import numpy as np
import streamlit as st
import plotly.graph_objects as go
from utils.quantum_ops import (
    sample_outcomes, empirical_correlation, theoretical_correlation,
    sweep_correlation, joint_probabilities
)

st.set_page_config(page_title="Entanglement & Correlation", page_icon="🌀", layout="wide")
st.title("🌀 Entanglement & Correlation (Bell Test)")

st.markdown(
    """
    Explore how **entangled particles** show strong **correlations** even when measured far apart.
    We'll use the Bell state **|Φ⁺⟩ = (|00⟩ + |11⟩)/√2** and measure along axes in the **X–Z plane**.
    """
)

with st.expander("🎞️ Quick analogy: two magic coins"):
    st.markdown(
        """
        Imagine two **magic coins** minted together. Whenever Alice and Bob flip them at matching orientations,
        they **always land the same** (both Heads or both Tails) — no matter how far apart they are.
        Change either coin's orientation, and the match rate changes smoothly like a **cosine** of the angle difference.
        Importantly, no signal travels between coins at flip time — the correlation is born from their **shared quantum state**.
        """
    )

colL, colR = st.columns([1, 1.2])
with colL:
    st.subheader("🎚️ Controls")
    degA = st.slider("Alice angle θ_A (degrees)", 0, 180, 0, step=1, help="Measurement axis in the X–Z plane")
    degB = st.slider("Bob angle θ_B (degrees)", 0, 180, 45, step=1, help="Measurement axis in the X–Z plane")
    trials = st.slider("Number of measurement pairs (trials)", 100, 200000, 5000, step=100)
    seed = st.number_input("Random seed (optional, -1 = random)", value=42, step=1)
    run = st.button("Run simulation")

    theta_a = np.deg2rad(degA)
    theta_b = np.deg2rad(degB)
    rng = np.random.default_rng(None if seed == -1 else int(seed))

    if run:
        r, s = sample_outcomes(theta_a, theta_b, trials, rng)
        E_emp = empirical_correlation(r, s)
        E_th = theoretical_correlation(theta_a, theta_b)

        st.markdown(f"**Empirical correlation** E ≈ **{E_emp:.3f}**, **Theory** cos(Δ) = **{E_th:.3f}** (Δ = {abs(degA-degB)}°)")

        # Joint outcome bars
        probs = joint_probabilities(theta_a, theta_b)
        labels = ["(+1,+1)","(+1,-1)","(-1,+1)","(-1,-1)"]
        values = [probs[(+1,+1)], probs[(+1,-1)], probs[(-1,+1)], probs[(-1,-1)]]
        fig_joint = go.Figure()
        fig_joint.add_bar(x=labels, y=values)
        fig_joint.update_layout(title="Joint outcome probabilities p(r,s)", yaxis_title="Probability", xaxis_title="(r, s)")
        st.plotly_chart(fig_joint, use_container_width=True)

        # Rolling correlation visualization
        rs_prod = r * s
        roll = np.cumsum(rs_prod) / (np.arange(trials) + 1)
        fig_roll = go.Figure()
        fig_roll.add_scatter(y=roll, mode="lines", name="Running mean of r·s")
        fig_roll.add_hline(y=E_th, line_dash="dot", annotation_text="Theory", annotation_position="top right")
        fig_roll.update_layout(title="Convergence of correlation E = ⟨r·s⟩", xaxis_title="Trial", yaxis_title="Correlation")
        st.plotly_chart(fig_roll, use_container_width=True)

with colR:
    st.subheader("📈 Correlation vs. angle difference")
    sweep_trials = st.slider("Trials per point for sweep", 100, 10000, 1500, step=100)
    points = st.slider("Number of points in sweep", 10, 200, 60, step=5)
    deltas = np.linspace(0, np.pi, points)
    emp, th = sweep_correlation(np.deg2rad(degA), deltas, trials_each=sweep_trials, rng=rng)

    fig = go.Figure()
    fig.add_scatter(x=np.rad2deg(deltas), y=emp, mode="markers", name="Empirical (Monte Carlo)")
    fig.add_scatter(x=np.rad2deg(deltas), y=th, mode="lines", name="Theory cos(Δ)")
    fig.update_layout(
        title="E(Δ) for |Φ⁺⟩ in the X–Z plane",
        xaxis_title="Δ = θ_B - θ_A (degrees)",
        yaxis_title="Correlation E",
        yaxis=dict(range=[-1.05, 1.05])
    )
    st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
with st.expander("🧠 What’s happening under the hood?"):
    st.markdown(
        r"""
        - We use the Bell state **|Φ⁺⟩ = (|00⟩ + |11⟩)/√2**.
        - Alice measures along axis **n_A(θ_A)** and Bob along **n_B(θ_B)** in the X–Z plane.
        - Outcomes are **r,s ∈ {+1,−1}**. The correlation is
          \[ E(θ_A, θ_B) = \langle \sigma_{n_A} \otimes \sigma_{n_B} \rangle = \cos(θ_A - θ_B). \]
        - We compute the exact joint probabilities **p(r,s)** via the **Born rule** and sample many times to show convergence.
        """
    )

st.success("Step 2 complete: Interactive Bell-test simulator with sliders, Monte Carlo sampling, and correlation plots.")
