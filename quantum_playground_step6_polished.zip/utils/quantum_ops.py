
import numpy as np

# ------------------ States & Bases ------------------
def bell_phi_plus():
    '''Return |Φ+> = (|00> + |11>)/sqrt(2) as a 4-vector.'''
    state = np.zeros(4, dtype=complex)
    state[0] = 1/np.sqrt(2)  # |00>
    state[3] = 1/np.sqrt(2)  # |11>
    return state

def projector_along_theta(theta: float, outcome: int):
    '''
    Projector Π_{theta}^{(outcome)} for a single qubit measured along
    axis n(theta) in the X-Z plane, where:
      n(theta) = (sinθ, 0, cosθ), θ in radians.
    outcome in {+1, -1} corresponds to |n,+> and |n,-> eigenstates.
    Returns a 2x2 projector.
    '''
    # eigenvectors of sigma·n in XZ-plane
    c = np.cos(theta/2.0)
    s = np.sin(theta/2.0)
    # |n,+> = [c, s], |n,-> = [-s, c] (up to a global phase)
    if outcome == +1:
        v = np.array([c, s], dtype=complex)
    else:
        v = np.array([-s, c], dtype=complex)
    return np.outer(v, np.conjugate(v))

def kron(*ops):
    '''Kronecker product of multiple matrices.'''
    res = np.array([[1.0+0j]])
    for A in ops:
        res = np.kron(res, A)
    return res

# ------------------ Probabilities & Sampling ------------------
def joint_probabilities(theta_a: float, theta_b: float, state: np.ndarray = None):
    '''
    Compute p(r,s) for r,s in {+1,-1} for measurements along theta_a, theta_b.
    Returns dict {(+1,+1): p, (+1,-1): p, (-1,+1): p, (-1,-1): p}
    '''
    if state is None:
        state = bell_phi_plus()
    rho = np.outer(state, np.conjugate(state))  # density matrix of |Φ+>
    
    probs = {}
    for r in (+1, -1):
        for s in (+1, -1):
            Pa = projector_along_theta(theta_a, r)
            Pb = projector_along_theta(theta_b, s)
            Pab = kron(Pa, Pb)
            # Born rule: Tr[Pab * rho]
            probs[(r, s)] = float(np.real(np.trace(Pab @ rho)))
    # numerical cleanup
    for k, v in probs.items():
        if v < 0 and v > -1e-12:
            probs[k] = 0.0
    # normalize (just in case of tiny numeric drift)
    Z = sum(probs.values())
    for k in probs:
        probs[k] /= Z
    return probs

def sample_outcomes(theta_a: float, theta_b: float, trials: int, rng=None):
    '''
    Monte Carlo sampling of (r,s) outcomes given measurement angles.
    Returns arrays r, s (each of length trials) with entries in {+1,-1}.
    '''
    if rng is None:
        rng = np.random.default_rng()
    probs = joint_probabilities(theta_a, theta_b)
    keys = [(+1,+1),(+1,-1),(-1,+1),(-1,-1)]
    p = np.array([probs[k] for k in keys])
    idx = rng.choice(4, size=trials, p=p)
    mapping = {
        0: (+1,+1),
        1: (+1,-1),
        2: (-1,+1),
        3: (-1,-1),
    }
    rs = np.array([mapping[i] for i in idx])
    r = rs[:,0]
    s = rs[:,1]
    return r, s

def empirical_correlation(r, s):
    '''E = mean(r * s).'''
    return float(np.mean(r * s))

def theoretical_correlation(theta_a: float, theta_b: float):
    '''
    For |Φ+> measured in a common XZ-plane, the correlation is:
        E = cos(theta_a - theta_b)
    '''
    return float(np.cos(theta_a - theta_b))

def sweep_correlation(theta_a: float, deltas: np.ndarray, trials_each: int = 2000, rng=None):
    '''
    Sweep Bob's angle: theta_b = theta_a + Δ, return empirical and theoretical E(Δ).
    '''
    if rng is None:
        rng = np.random.default_rng()
    emp = []
    th = []
    for d in deltas:
        theta_b = theta_a + d
        r, s = sample_outcomes(theta_a, theta_b, trials_each, rng)
        emp.append(empirical_correlation(r, s))
        th.append(theoretical_correlation(theta_a, theta_b))
    return np.array(emp), np.array(th)


# ------------------ CHSH Calculation ------------------
def chsh_value(theta_a, theta_ap, theta_b, theta_bp, trials=2000, rng=None):
    '''Compute S = E(a,b) + E(a,b') + E(a',b) - E(a',b') for given angles.'''
    if rng is None:
        rng = np.random.default_rng()
    r1, s1 = sample_outcomes(theta_a, theta_b, trials, rng)
    r2, s2 = sample_outcomes(theta_a, theta_bp, trials, rng)
    r3, s3 = sample_outcomes(theta_ap, theta_b, trials, rng)
    r4, s4 = sample_outcomes(theta_ap, theta_bp, trials, rng)
    E1 = empirical_correlation(r1, s1)
    E2 = empirical_correlation(r2, s2)
    E3 = empirical_correlation(r3, s3)
    E4 = empirical_correlation(r4, s4)
    S_emp = E1 + E2 + E3 - E4
    S_th = (np.cos(theta_a - theta_b) + np.cos(theta_a - theta_bp)
            + np.cos(theta_ap - theta_b) - np.cos(theta_ap - theta_bp))
    return S_emp, S_th


# ------------------ Quantum Teleportation Utilities ------------------
def single_qubit_state_from_bloch(theta: float, phi: float) -> np.ndarray:
    """|ψ(θ,φ)⟩ = cos(θ/2)|0⟩ + e^{iφ} sin(θ/2)|1⟩."""
    a = np.cos(theta/2.0)
    b = np.exp(1j*phi) * np.sin(theta/2.0)
    return np.array([a, b], dtype=complex)

# Basic gates
I = np.eye(2, dtype=complex)
X = np.array([[0,1],[1,0]], dtype=complex)
Z = np.array([[1,0],[0,-1]], dtype=complex)
H = (1/np.sqrt(2)) * np.array([[1,1],[1,-1]], dtype=complex)

def apply_single_qubit(state: np.ndarray, U: np.ndarray, target: int, n_qubits=3) -> np.ndarray:
    """Apply single-qubit gate U to 'target' (0 = first/leftmost)."""
    ops = []
    for q in range(n_qubits):
        ops.append(U if q==target else I)
    U_full = ops[0]
    for k in range(1, n_qubits):
        U_full = np.kron(U_full, ops[k])
    return U_full @ state

def apply_cnot(state: np.ndarray, control: int, target: int, n_qubits=3) -> np.ndarray:
    """CNOT with given control->target on n_qubits (small n, brute force)."""
    dim = 2**n_qubits
    out = np.zeros_like(state)
    for basis in range(dim):
        bits = [(basis >> (n_qubits-1-q)) & 1 for q in range(n_qubits)]
        if bits[control] == 1:
            # flip target bit
            bits[target] ^= 1
            nb = 0
            for q in range(n_qubits):
                nb = (nb<<1) | bits[q]
            out[nb] += state[basis]
        else:
            out[basis] += state[basis]
    return out

def partial_trace_rho(rho: np.ndarray, keep: int, n_qubits=3) -> np.ndarray:
    """Partial trace over all qubits except 'keep'. Returns 2x2 density matrix."""
    # reshape to (2,2,...,2, 2,2,...,2) with bra and ket indices
    dims = [2]*n_qubits
    rho_t = rho.reshape(dims + dims)
    # trace over all indices where q != keep
    for q in range(n_qubits):
        if q == keep:
            continue
        rho_t = np.trace(rho_t, axis1=q, axis2=q+n_qubits)
    return rho_t

def bloch_vector(rho1: np.ndarray):
    """Return (x,y,z) for a 2x2 density matrix."""
    x = 2*np.real(rho1[0,1])
    y = -2*np.imag(rho1[0,1])
    z = np.real(rho1[0,0] - rho1[1,1])
    return float(x), float(y), float(z)

def teleportation_once(theta: float, phi: float, rng=None):
    """Perform one run of teleportation. Returns (m0,m1,fidelity, bob_state_rho, steps)."""
    if rng is None:
        rng = np.random.default_rng()
    # qubit order: q0 (unknown at Alice), q1 (Alice's half of Bell), q2 (Bob)
    # Prepare |psi> on q0
    psi = single_qubit_state_from_bloch(theta, phi)
    # Initial 3-qubit |000>
    state = np.zeros(8, dtype=complex); state[0] = 1.0
    # Put psi on q0:
    U0 = np.kron(np.kron(np.array([[psi[0], psi[1]],[0,0]], dtype=complex), I), I)  # not a unitary; simpler to build through replacement
    # Simpler: construct full state explicitly as |psi> ⊗ |0> ⊗ |0>
    state = np.kron(np.kron(psi, np.array([1,0], dtype=complex)), np.array([1,0], dtype=complex))
    # Create Bell pair between q1 and q2: H on q1, CNOT q1->q2
    state = apply_single_qubit(state, H, target=1)
    state = apply_cnot(state, control=1, target=2)
    # Teleportation ops: CNOT q0->q1, H on q0
    state = apply_cnot(state, control=0, target=1)
    state = apply_single_qubit(state, H, target=0)

    # Measure q0 and q1 in Z-basis -> m0, m1
    # Compute probabilities by summing amplitudes over matching basis states
    amps = state
    probs = np.zeros(4)
    outcomes = [(0,0),(0,1),(1,0),(1,1)]
    for i,(m0,m1) in enumerate(outcomes):
        # positions where bits (q0,q1) equal (m0,m1)
        p = 0.0
        vect = np.zeros_like(amps)
        for basis in range(8):
            b0 = (basis >> 2) & 1  # q0
            b1 = (basis >> 1) & 1  # q1
            if b0==m0 and b1==m1:
                p += np.abs(amps[basis])**2
        probs[i] = p
    probs = probs / np.sum(probs)

    # sample an outcome
    idx = rng.choice(4, p=probs)
    m0, m1 = outcomes[idx]

    # collapse post-measurement state (project & renormalize)
    post = np.zeros_like(amps)
    norm = 0.0
    for basis in range(8):
        b0 = (basis >> 2) & 1
        b1 = (basis >> 1) & 1
        if b0==m0 and b1==m1:
            post[basis] = amps[basis]
            norm += np.abs(amps[basis])**2
    post = post / np.sqrt(norm + 1e-16)

    # Bob's corrections on q2: if m1==1 apply X; if m0==1 apply Z
    if m1==1:
        post = apply_single_qubit(post, X, target=2)
    if m0==1:
        post = apply_single_qubit(post, Z, target=2)

    # Fidelity between Bob's qubit and |psi>
    rho = np.outer(post, np.conjugate(post))
    rho_bob = partial_trace_rho(rho, keep=2)
    fid = np.real(np.conjugate(psi) @ rho_bob @ psi)

    # Save key step states (optional minimal snapshots)
    steps = {
        'probs_m0m1': {str(outcomes[i]): float(probs[i]) for i in range(4)},
        'm0': int(m0), 'm1': int(m1)
    }
    return m0, m1, float(fid), rho_bob, steps

def teleportation_batch(theta: float, phi: float, shots: int = 1000, rng=None):
    if rng is None:
        rng = np.random.default_rng()
    counts = {(0,0):0,(0,1):0,(1,0):0,(1,1):0}
    fids = []
    rhos = []
    for _ in range(shots):
        m0, m1, fid, rho_bob, _ = teleportation_once(theta, phi, rng)
        counts[(m0,m1)] += 1
        fids.append(fid)
        rhos.append(rho_bob)
    avg_fid = float(np.mean(fids))
    return counts, avg_fid


# ------------------ Noise Channels & Decoherence ------------------
def apply_noise_channel(rho: np.ndarray, model: str, gamma: float) -> np.ndarray:
    """Apply a single-qubit CPTP map specified by 'model' at strength gamma in [0,1]."""
    gamma = float(np.clip(gamma, 0.0, 1.0))
    if model == "phase":
        # Phase damping (pure dephasing)
        E0 = np.array([[1,0],[0,np.sqrt(1-gamma)]], dtype=complex)
        E1 = np.array([[0,0],[0,np.sqrt(gamma)]], dtype=complex)
    elif model == "amplitude":
        # Amplitude damping (|1> -> |0> relaxation)
        E0 = np.array([[1,0],[0,np.sqrt(1-gamma)]], dtype=complex)
        E1 = np.array([[0,np.sqrt(gamma)],[0,0]], dtype=complex)
    else:
        raise ValueError("Unknown model: " + str(model))
    return E0 @ rho @ E0.conj().T + E1 @ rho @ E1.conj().T

def evolve_under_noise(theta: float, phi: float, gammas: np.ndarray, model: str):
    """Return lists of density matrices, |rho01| coherences, and Bloch vectors for gamma path."""
    psi = single_qubit_state_from_bloch(theta, phi)
    rho0 = np.outer(psi, np.conjugate(psi))
    states, coherences, bloch = [], [], []
    for g in gammas:
        rho_g = apply_noise_channel(rho0, model, float(g))
        states.append(rho_g)
        coherences.append(np.abs(rho_g[0,1]))
        bloch.append(bloch_vector(rho_g))
    return states, np.array(coherences), np.array(bloch)


# ------------------ Export Helpers ------------------
def export_csv(data_dict, filename="quantum_data.csv"):
    '''Export a dict of lists as a CSV file and return its path.'''
    import pandas as pd, io
    df = pd.DataFrame(data_dict)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue()
